<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\PasienController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/kabar', function () {
    return view('kondisi');
});
Route::get('/pasien', function () {
    return view('pasien');
});

route::get('/admin', [AdminController::class, 'index']);
route::get('/pegawai',[PegawaiController::class, 'index']);
route::get('/admin/pasien',[PasienController::class, 'index']);
