<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $nama = "Adelia Afifatuzzahra";
        echo $nama;
    ?>   
</body>
</html><?php /**PATH C:\xampp-new\htdocs\Praktikum Web2\praktikum09\resources\views/kondisi.blade.php ENDPATH**/ ?>